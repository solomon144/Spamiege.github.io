package com.example.eventtrackerapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display); // Ensure this layout contains recyclerView

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get all events from the database
        List<EventItem> eventList = dbHelper.getAllEvents();

        // Set layout manager (Grid with 2 columns)
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Set adapter
        eventAdapter = new EventAdapter(eventList);
        recyclerView.setAdapter(eventAdapter);
    }
}

