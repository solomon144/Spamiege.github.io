package com.example.eventtrackerapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    EditText messageBox;
    Button requestPermissionButton, sendSMSButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);  // Make sure this matches your layout file name

        messageBox = findViewById(R.id.messageBox);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        sendSMSButton = findViewById(R.id.sendSMSButton);

        // Initially disable send button
        sendSMSButton.setEnabled(false);

        requestPermissionButton.setOnClickListener(v -> {
            if (checkSmsPermission()) {
                Toast.makeText(this, "Permission already granted!", Toast.LENGTH_SHORT).show();
                sendSMSButton.setEnabled(true);
            } else {
                requestSmsPermission();
            }
        });

        sendSMSButton.setOnClickListener(v -> {
            if (checkSmsPermission()) {
                sendSms();
            } else {
                Toast.makeText(this, "Permission not granted.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void sendSms() {
        String message = messageBox.getText().toString().trim();
        String phoneNumber = "1234567890"; // You can make this editable too

        if (!message.isEmpty()) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent to " + phoneNumber, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a message.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMSButton.setEnabled(true);
                Toast.makeText(this, "Permission granted. You can now send SMS.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
