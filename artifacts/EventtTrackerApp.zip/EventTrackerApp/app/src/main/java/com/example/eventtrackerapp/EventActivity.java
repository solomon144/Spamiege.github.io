package com.example.eventtrackerapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EventActivity extends AppCompatActivity {

    EditText editTextEventName, editTextEventDate;
    Button buttonAdd;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDate = findViewById(R.id.editTextEventDate);
        buttonAdd = findViewById(R.id.buttonAdd);
        dbHelper = new DatabaseHelper(this);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextEventName.getText().toString();
                String date = editTextEventDate.getText().toString();

                if (name.isEmpty() || date.isEmpty()) {
                    Toast.makeText(EventActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean inserted = dbHelper.addEvent(name, date);
                    if (inserted) {
                        Toast.makeText(EventActivity.this, "Event added!", Toast.LENGTH_SHORT).show();
                        editTextEventName.setText("");
                        editTextEventDate.setText("");
                    } else {
                        Toast.makeText(EventActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
