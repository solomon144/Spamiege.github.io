package com.example.eventtrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonLogin, buttonCreateAccount, buttonViewData, buttonSendSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Handle edge-to-edge insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonViewData = findViewById(R.id.buttonViewData);      // Add this button in XML
        buttonSendSMS = findViewById(R.id.buttonSendSMS);        // Add this button in XML

        // Login button logic
        buttonLogin.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Login successful (placeholder)", Toast.LENGTH_SHORT).show();
                // Navigate to Data Display screen after login
                Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            }
        });

        // Create account button logic
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a username and password to register", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Account created (placeholder)", Toast.LENGTH_SHORT).show();
                // Optionally redirect to DataDisplay
                Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            }
        });

        // View Data Grid Button logic
        buttonViewData.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });

        // Send SMS Button logic
        buttonSendSMS.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }
}
