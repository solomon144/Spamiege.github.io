package com.example.eventtrackerapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display); // Make sure this layout exists

        // Initialize RecyclerView or GridView here if needed
        // Example: RecyclerView recyclerView = findViewById(R.id.recyclerView);
    }
}
